import { Component } from '@angular/core';

@Component({
  selector: 'root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title : string = 'Buen dia Grupo!!!!';
  //lista : string[] = ["Uno", "Dos", "Tres"];
  lista : Array<string>;
  //lista : Array<string> = new Array<string>();

  texto : string = 'Hola!!!';

  constructor() {
  	console.log('Esto es el constructor.');
  	this.lista = [];
  }

  ngOnInit() {
  	console.log('Esto es el ngOnInit');
  	this.lista.push('Uno');
  	this.lista.push('Dos');
  	this.lista.push('Tres');
  	this.lista.push('Cuatro');
  }

  mostrar() {
  	console.log(this.texto);
  }

  agregar(texto : string) {
  	this.lista.push(texto);
  }

  modificar(index : number) {
  	this.texto = this.lista[index];
  	this.lista.splice(index, 1);
  }

  getTexto() : string {
  	return this.texto;
  }
}
